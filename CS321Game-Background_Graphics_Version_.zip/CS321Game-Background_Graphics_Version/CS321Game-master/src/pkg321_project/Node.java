
package pkg321_project;

public class Node {
      int data;
     String story;
     Node left;
     Node right; //left and right children
     
    //constructor
        public  Node(int t_data, String t_story){
            data=t_data; 
            left=null;
            right=null;
            story=t_story;
      }
}

